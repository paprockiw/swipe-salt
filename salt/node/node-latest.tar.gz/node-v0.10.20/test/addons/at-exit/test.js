var binding = require('./build/Release/binding');
